import pandas as pd

data = pd.read_csv('Loop_PTB7_maw.csv')

# Print the column names to verify
print("Columns in the CSV file:", data.columns)

d1 = data["d1p"]
d2 = data["d2p"]
d3 = data["d3p"]
data_result = data["AVT"]