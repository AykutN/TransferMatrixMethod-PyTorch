import pandas as pd

data = pd.read_csv('Loop_PTB7_maw.csv')

# Print the column names to verify
print("Columns in the CSV file:", data.columns)


